The code contained within this folder, specifically calcx.py, is an extended
version of the calc.py that is included with the PLY package. The extension
includes % and // operators, as well as support for lists and operators between
lists of the same size.

Code written by Matthew Virgin for COS 301

25 test cases are included in sampleip.txt, provided by the professor
the outputs of these test cases are included in outp.txt

samplei1.txt - samplei5.txt feature various test cases, with the output of these
stored as out1.txt - out5.txt